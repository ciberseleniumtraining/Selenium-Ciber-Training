package com.htc.javascript;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.htc.webdrivergenerator.DriverGenerator;
public class PageScroll {
	WebDriver driver;
	String URL = "http://www.seleniumhq.org/";

	@BeforeClass
	public void setUp() {
		driver = DriverGenerator.genDriver();
		driver.get(URL);
		driver.manage().window().maximize();
	}

	@Test(priority=1)
	public void scrollingToBottomofAPage() throws InterruptedException {
		driver.navigate().to(URL);
		 ((JavascriptExecutor) driver)
         .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		 Thread.sleep(3000);
	}

	@Test(priority=2)
	public void scrollingToElementofAPage() throws InterruptedException {
		//driver.navigate().to(URL+"directory/companies?trk=hb_ft_companies_dir");
		WebElement element = driver.findElement(By.linkText("Selenium WebDriver"));
		//element.click();
		((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView();", element);
		Thread.sleep(3000);
	}
	
	@Test(priority=3)
	public void scrollingByCoordinatesofAPage() throws InterruptedException {
		//driver.navigate().to("https://seleniumhq.wordpress.com/");
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0,600)");
		Thread.sleep(3000);
	}
	
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}