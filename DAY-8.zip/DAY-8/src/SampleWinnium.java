import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;

public class SampleWinnium {

	WiniumDriver driver=null;
	
	@Before
	public void setUpEnviroment() throws IOException
	{
		DesktopOptions options=new DesktopOptions();
		options.setApplicationPath("C:\\Windows\\System32\\notepad.exe");
		
		try
		{	
			driver=new WiniumDriver(new URL("http://localhost:9999"),options);
		
		}
		catch(MalformedURLException e)
		{
			e.printStackTrace();
		}
	}
		@org.junit.Test
		public void testNotepadApp() throws InterruptedException
		{
			Thread.sleep(3000);
			driver.findElementByClassName("Edit").sendKeys("This is sample code");
			
			
		}
		
		@After
		public void teardown() throws IOException
		{
			//driver.close();
		
	}
	
	
}
