package SIKULI;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.annotations.Test;
import com.htc.webdrivergenerator.DriverGenerator;
public class STMSikuliClassgoogle {

	@Test
	public void googleLogin() throws FindFailed{
		
	// Creating Object of 'Screen' class
	//Screen is a base class provided by Sikuli.
	//It allows us to access all the methods provided by Sikuli.
	Screen screen = new Screen();
	// Creating Object of Pattern class and specify the path of specified images
	Pattern login = new Pattern("D://Sayooj//googlesign.png");
	Pattern emailtextbox=new Pattern("D://Sayooj//emailgoogle.PNG") ;
	Pattern nextbutton=new Pattern("D://Sayooj//nextgoogle.PNG");
	WebDriver driver = DriverGenerator.genDriver();
	// To maximize the browser
	driver.manage().window().maximize() ;
	// Open google
	driver.get("https://www.google.co.in/");
	screen.wait(login, 10);	 	// This will click on login button
	screen.click(login);
	screen.wait(emailtextbox,10);
	screen.type(emailtextbox, "testuser@gmail.com");
	screen.wait(nextbutton,5);
	screen.click(nextbutton);
	
	}
 
}
