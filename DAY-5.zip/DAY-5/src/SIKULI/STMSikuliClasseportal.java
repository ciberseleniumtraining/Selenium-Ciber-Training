package SIKULI;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.annotations.Test;

import com.htc.webdrivergenerator.DriverGenerator;

public class STMSikuliClasseportal {

	@Test
	public void eportalLogin() throws FindFailed{
		
	// Creating Object of 'Screen' class
	//Screen is a base class provided by Sikuli. It allows us to access all the methods provided by Sikuli.
	Screen screen = new Screen();
	Pattern login = new Pattern("\\src\\img\\capture.png");
	// Initialization of driver object to launch chrome browser 
	  WebDriver driver=DriverGenerator.genDriver();
	// To maximize the browser
	driver.manage().window().maximize() ;
	// Open eportal
	driver.get("https://eportal.htcindia.com/home/");
	screen.wait(login, 10);	 
	Pattern empidtextbox=new Pattern("\\src\\img\\empid.PNG") ;
	Pattern passwordtextbox=new Pattern("\\src\\img\\password.PNG") ;
	Pattern nextbutton=new Pattern("\\src\\img\\login.PNG");
	
	// Calling 'type' method to enter username in the email field using 'screen' object
	//screen.type(username, "testuser@gmail.com");
	// Calling the same 'type' method and passing text in the password field
	//screen.type(password, "testpassword");
	// This will click on login button
	screen.click(login);
	screen.type(empidtextbox,"1234");
		// Calling the same 'type' method and passing text in the password field
	screen.type(passwordtextbox, "testpassword");
	screen.click(nextbutton);
	}
 
}
