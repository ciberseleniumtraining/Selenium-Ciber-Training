package selectsample;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import com.htc.webdrivergenerator.DriverGenerator;
import org.openqa.selenium.interactions.Action;

public class MultiSelect {

   public static void main(String[] args) throws InterruptedException {
	  
	   WebDriver driver = DriverGenerator.genDriver();
	   driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

      driver.navigate().to("http://demos.devexpress.com/aspxeditorsdemos/ListEditors/MultiSelect.aspx");

     // driver.manage().window().maximize();
      Thread.sleep(1000);
    // driver.findElement(By.id("ContentHolder_lbSelectionMode_B-1")).click();
      driver.findElement(By.xpath("//*[@id='ControlOptionsTopHolder_lbSelectionMode_B-1']")).click();
      Thread.sleep(1000);
      driver.findElement(By.xpath("//*[@id='ControlOptionsTopHolder_lbSelectionMode_DDD_L_LBI1T0']"));
      
      // Perform Multiple Select
      Actions builder = new Actions(driver);
      WebElement select = driver.findElement(By.id("ContentHolder_lbFeatures_LBT"));
      List<WebElement> options = select.findElements(By.tagName("td"));
      for(WebElement o:options) {
    	  System.out.println(o.getAttribute("value"));
      }
      System.out.println(options.size());
      Action multipleSelect = 
         builder.keyDown(Keys.CONTROL).click(options.get(2)).click(options.get(4)).click(options.get(6)).build();
      
      multipleSelect.perform();
      //driver.close();
   }
}