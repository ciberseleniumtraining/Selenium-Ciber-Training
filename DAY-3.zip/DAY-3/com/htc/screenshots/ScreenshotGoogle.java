package com.htc.screenshots;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.testng.annotations.Test;

import com.htc.webdrivergenerator.DriverGenerator;

public class ScreenshotGoogle {

	@Test
	public void TestJavaS1() {
		// Open Chrome
		WebDriver driver = DriverGenerator.genDriver();

		// Maximize the window
		driver.manage().window().maximize();

		// Pass the url
		driver.get("http://www.google.com");

		// Take screenshot and store as a file format
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			// now copy the� screenshot to desired location using copyFile //method
			FileUtils.copyFile(src, new File("./Screenshots/error.png"));
		}

		catch (IOException e) {
			System.out.println(e.getMessage());

		}
	}
}